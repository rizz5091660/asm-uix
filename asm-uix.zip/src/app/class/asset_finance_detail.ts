import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap/datepicker/ngb-date-struct";

export class AssetFinanceDetail{
    entry_date:NgbDateStruct;
    cost_factor_typ:string;
    description:string;
    cost:number;

}
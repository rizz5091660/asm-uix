export class AssetFinanceSummary{
    purchase_cost:number=0;
    operational_cost:number=0;
    current_book_val:number=0;
    total_cost_ownership:number=0;
}